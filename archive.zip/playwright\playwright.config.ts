// Archived Playwright config (kept out of active tree for production)
// Original config can be restored from the development branch when needed.
export default {}
